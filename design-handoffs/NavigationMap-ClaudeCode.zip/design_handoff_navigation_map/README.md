# Handoff: Navigation Map Component

## Overview
A reusable, dark skeuomorphic navigation/map UI component for an EV/automotive-style interface. Two variants are included: a full-bleed dashboard version and a compact widget version intended for a component library (`usual-ui`).

## About the Design Files
The files in this bundle are **design references built in HTML/CSS/SVG** — high-fidelity prototypes of look, motion, and behavior, not production code to copy verbatim. The task is to **recreate these designs in the target codebase's existing environment** (React, Vue, etc., following its component/prop/styling conventions) — or, if no environment exists yet, to pick the most suitable framework and implement there.

## Fidelity
**High-fidelity.** Colors, spacing, typography, shadow stacks, and motion timings below are final values taken directly from the HTML/CSS source — recreate pixel-for-pixel where the target stack allows.

## Design System Reference
Built on a dark skeuomorphic material system (top-down lighting, raised shell / inset-well depth hierarchy). Reference: https://github.com/zzzzshawn/skeumorphic-ui/blob/main/SKill.md — read this first; it defines the shadow-stack recipes reused throughout.

Core recipes:
- Scene background: `#0f0f0f`
- Raised shell: `linear-gradient(180deg, #202020 0%, #191919 100%)` with shadow `0 1px 0.5px #ffffff1a inset, 0 1px 2px #ffffff35 inset, 0 10px 10px -9px #00000070, 0 20px 20px -14px #00000060, 0 0 6px 0 #00000060`
- Inset/carved surface: background `#0e0e0e`–`#101010`, shadow `0 0.5px 0 #ffffff50, 0 2px 6px #00000090 inset`
- Depth order (mandatory): scene → raised parent shell → inset zones (map well, readout wells) → raised controls (buttons, speed sign) → readout text/details.

## Screens / Views

### 1. NavMap (full-bleed dashboard variant) — `NavMap.dc.html`
**Purpose:** Full-screen in-car navigation surface.
**Layout:** Fills 100% width/height of its container. Structure: outer padded scene (`#0f0f0f`) → raised shell (padding ~clamp(6–11px), border-radius ~clamp(16–26px)) → inset map well (border-radius ~clamp(11–18px), overflow hidden) containing:
  - A 3D-tilted SVG map layer (`transform: perspective(3200px) rotateX(50deg) rotateZ(-15deg) scale(.74)`, translateY(-7%)), masked with a top-to-bottom gradient so the horizon fades.
  - Top overlay row: destination pill (left) + control cluster (recenter/zoom in/zoom out, right), both raised-shell chips with inset-well circular buttons.
  - Bottom overlay: "Then" next-instruction chip + circular speed-limit sign, then the main HUD bar.

**Components:**
- **Destination pill**: raised shell, 24px icon well (red dot marker), label "DESTINATION" (10px mono, uppercase, `#8e8e8e`→ use ≥.66 alpha equivalent for contrast), value 13.5px/600 `#ededed`.
- **Control cluster**: 3 circular buttons (38px) each in its own inset well (per SKill.md "nested inset + popping button" pattern); icons: recenter (compass diamond), zoom in/out (plus/minus). Active state: `scale(.94)` + deeper inset shadow. Hover: brighter icon + softer glow shadow.
- **Speed-limit sign**: 72–82px circle, white-ish face (`radial-gradient(#fbfbfb → #e6e6e4)`) with 4–5px red ring border (`#b8322a`/`#d8352a`), mono digits (24–27px, `#16110f`/`#0c1017`), unit label below (7–7.5px).
- **Turn instruction HUD bar**: raised shell, border-radius ~18–24px, contains:
  - Turn icon well (54–66px) with SVG path+arrowhead glyph (8 directions supported — see Design Tokens).
  - Distance (32–44px mono bold) + unit (13–15px) + street name (15–19px, 600 weight) stacked.
  - Vertical divider.
  - Arrival / Remaining / Range readouts, each its own inset well, 9–10px uppercase mono label + 15–17px value; Range has a small green status dot (`#4fbf87`).
- **Vehicle marker** (on map): concentric circles + heading triangle, subtle pulsing ring animation, bobbing float animation.
- **Route**: multi-layer SVG path stroke — dark casing, blurred glow, solid color stroke, animated "draw-in" highlight, animated dashed flow overlay. Default color `#c8382c` (prop-controlled).

### 2. NavigationMap (compact widget variant) — `NavigationMap.dc.html`
**Purpose:** Drop-in widget for a component library / app surface, not a full page.
**Layout:** `max-width: 500px`, `aspect-ratio: 500/316`, `min-height: 260px` — responsive, driven by a `ResizeObserver` on the map well (not viewport media queries), so it adapts to its actual rendered container width:
  - ≥ ~445px: full composition (turn/distance/street + divider + Arrival/Remaining/Range).
  - 355–445px: Range readout hidden.
  - < 355px: entire readout group + divider hidden, speed sign shrinks 46px→38px and repositions; only turn direction + distance + street remain — never clips or scrolls horizontally.
**Components:** Same visual language as NavMap but re-proportioned natively (not scaled): 18–26px icon wells, 26px control buttons, 36–46px turn/speed elements, 21px distance value, 11.5px street name, 7.5–8px mono labels, single 52px-tall HUD bar.

## Interactions & Behavior
- **Recenter button**: resets pointer-parallax tilt and zoom to defaults.
- **Zoom in/out buttons**: adjust a `zoom` state value (clamped ~0.72–1.7 full variant, ~0.76–1.6 widget variant) applied as a CSS `scale()` on the map's live-tilt layer.
- **Pointer parallax**: `onPointerMove` over the map well computes normalized `px, py` (-1..1) from cursor position; drives a subtle rotate + translate on the map layer (`transition: transform .8s cubic-bezier(.16,.84,.24,1)`). `onPointerLeave` resets to 0.
- **Route draw-in**: on mount, a highlight stroke animates `stroke-dashoffset` 1000→0 over 2.2–2.4s (`cubic-bezier(.4,0,.2,1)`).
- **Route flow**: a dashed overlay stroke animates `stroke-dashoffset` continuously (linear, 3.4–4.2s loop) to suggest directional flow along the route.
- **Marker**: pulsing ring (`r` 22–26 → 58–74, opacity 1→0, ease-out, ~2.8–3.4s loop) + gentle vertical bob (`translateY(0/-2px/-3px)`, ease-in-out, ~3.6–4.4s loop).
- **Map drift**: whole map layer very subtly translates (`±6–10px`) on a slow 26–34s ease-in-out loop for ambient life.
- **Button tactile feedback**: hover brightens icon color + softens/enlarges the black lift shadow; active applies `scale(.92–.96)` plus a deeper inset shadow (spring-like, `cubic-bezier(.3,1.6,.5,1)`, ~120ms).
- **Entrance**: top/bottom overlay chips fade+slide in on mount (`translateY(8–14px)→0`, opacity 0→1, ease-out, .45–.7s, staggered slightly by element).
- **Responsive collapse (widget only)**: driven by `ResizeObserver`, described above — implement as container queries or an equivalent resize-aware mechanism in the target framework, not viewport media queries, since this is meant to be embedded at arbitrary widths inside other layouts.

## State Management
- `zoom` (number): current map zoom scale, adjusted by zoom in/out, reset by recenter.
- `px, py` (number, -1..1): pointer position relative to map well center, used for parallax tilt; reset on pointer leave.
- `width` (widget variant only, number): current rendered width of the map well, read via ResizeObserver; drives the responsive breakpoints (355px, 445px) described above.
- No async/data-fetching requirements — all content is prop-driven, synchronous.

## Design Tokens

**Colors**
- Scene: `#0f0f0f`
- Raised shell gradient: `#202020` → `#191919`
- Map base: `#0d0d0d` / `#0e0e0e`
- Building fills: `#1b1b1b` (opacity varies 0.35–0.9 per building)
- Minor road: `#1f1f1f` (3px), Major road: `#282828` (11px) with `#343434` centerline (3px, .8 opacity)
- Park fill: `#131512`; Water fill: `#101315`
- Route (default): `#c8382c` — prop `routeColor`, alternates offered: `#c2762f` (amber), `#4a8fb5` (blue), `#4fbf87` (green)
- Route highlight overlay: `#ffb8ad` / `#ffd2c9`
- Marker face: `#1c1c1c` ring on `#141414`, heading chevron `#f0f0f0`
- Speed sign: face `#fbfbfb`→`#e6e6e4`, ring `#b8322a`, digits `#16110f`
- Turn icon accent: `#d8564a`
- Text: primary `#e9e9e9`/`#ededed`, secondary `#cfcfcf`/`#d6d6d6`, muted labels `#8a8a8a`/`#858585`
- Status green (range dot): `#4fbf87`
- Link colors (if any added): default `#d8564a`, hover `#e8796d`

**Typography**
- UI font: Archivo (400/500/600/700)
- Mono/numeric font: JetBrains Mono (400/500/700)
- Distance value: 21px (widget) / clamp(30–44px) (full), weight 700, letter-spacing -.03 to -.04em
- Street name: 11.5–15px (widget) / clamp(15–19px) (full), weight 600
- Uppercase micro-labels: 7.5–10px, letter-spacing .14–.18em, uppercase
- Readout values: 11–17px, weight 500
- Destination value: 11.5–14px, weight 600

**Shadows / Depth (see SKill.md for full recipes)**
- Raised shell: `0 1px 0.5px #ffffff1a inset, 0 1px 2px #ffffff35 inset, 0 10px 10px -9px #00000070, 0 20px 20px -14px #00000060, 0 0 6px 0 #00000060`
- Inset well: `0 0.5px 0 #ffffff50, 0 2px 6px #00000090 inset`

**Border radius**
- Outer shell: 20–28px (widget: 20px)
- Map well: 15–18px
- HUD bar: 13–24px
- Chips/pills: 9–14px
- Buttons/wells: fully round (999px) or 8–14px for square wells

**Motion**
- Parallax tilt: .8s `cubic-bezier(.16,.84,.24,1)`
- Button press: ~.12s `cubic-bezier(.3,1.6,.5,1)` (spring)
- Route draw-in: 2.2–2.4s `cubic-bezier(.4,0,.2,1)`
- Ambient drift/bob/ring loops: 2.8s–4.4s, ease-in-out/ease-out, infinite

## Component API (props)
Shared across both variants unless noted:
- `distance` (string, e.g. `"900 m"`) — parsed into numeric value + unit for display.
- `streetName` (string)
- `speedLimit` (number)
- `speedUnit` (`"MPH" | "KM/H"`)
- `turnDirection` (`"left" | "slight-left" | "straight" | "slight-right" | "right" | "sharp-right" | "u-turn" | "roundabout"`) — maps to a distinct SVG glyph.
- `routeColor` (string, hex)
- `mapTheme` (`"graphite" | "midnight" | "ember" | "teal"`) — subtle color-wash tint over the map (blend-mode soft-light, low opacity 0.05–0.1).
- `destination` (string)
- `destinationLabel` (string, widget variant; label above destination value, e.g. "Destination")
- `nextInstruction` (string, full variant only — "then" instruction text)
- `arrivalTime` / `etaLabel` (string — widget uses `arrivalTime`, full variant `etaLabel`; treat as aliases)
- `remaining` / `remainingLabel` (string — aliases, e.g. `"8.2 km"`)
- `range` / `rangeLabel` (string — aliases, e.g. `"214 km"`)
- `currentLocation` (`{ lat: number, lng: number }`) — passthrough, not currently wired to real geo rendering (map geometry is procedurally generated, not tile-based).
- `destinationCoord` (`{ lat: number, lng: number }`, full variant) — same passthrough note.

**Note on map geometry:** the road/building/park layout is procedurally generated (seeded RNG) for visual richness, not sourced from real map data or tiles. If real map integration is needed, the SVG map layer should be swapped for an actual map renderer (e.g. Mapbox GL, MapLibre) while keeping the overlay HUD/controls/marker/route-styling layer as-is.

## Assets
No external image/icon assets — all iconography is inline SVG (paths/circles), no icon font or image files used.

## Files
- `NavMap.dc.html` — full-bleed dashboard variant (reference implementation)
- `NavigationMap.dc.html` — compact, resize-aware widget variant (reference implementation, intended for the component library)

Both are self-contained HTML files usable directly in a browser for visual/behavioral reference; open them to inspect exact markup, inline styles, and the animation/state logic in the embedded script.
