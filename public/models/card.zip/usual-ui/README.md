# SavingsChallengeCard for usual-ui

A group savings goal rendered as a moulded object, built on the same
material recipe as ReceiptPrinter: a top-lit shell, a recessed dot-matrix
readout, and a milestone curve that fills as the pot grows.

## Where these files go

Drop this into the existing usual-ui repo, preserving the paths below:

    src/components/SavingsChallengeCard/SavingsChallengeCard.tsx
    src/components/SavingsChallengeCard/dot-matrix.tsx
    src/components/SavingsChallengeCard/index.ts
    src/components/SavingsChallengeCardDemo/SavingsChallengeCardDemo.tsx
    src/components/SavingsChallengeCardDemo/index.ts
    public/textures/plastic-noise.svg

The texture is already in the repo (ReceiptPrinter uses it) -- the copy
here is only a fallback in case that file ever moves.

## Dependencies

All already used elsewhere in usual-ui, no package.json changes needed:
@phosphor-icons/react, motion, clsx, tailwind-merge (via src/lib/utils.ts
cn helper), Tailwind CSS v4 with arbitrary-value syntax.

## Wiring it up (optional, only if you want a showcase entry)

1. Add a route in src/App.tsx pointing at a SavingsChallengeCardSource
   page, following the ReceiptPrinterSource pattern.
2. Add a card to src/pages/Home for the showcase grid, following the
   existing entries (see src/components/navigation-map-card-demo.tsx for
   the shape of a showcase preview card).
3. If usual-ui documents props via src/lib/component-docs.tsx, add a
   savingsChallengeCardDoc entry there, following receiptPrinterDoc.

None of this is required for the component to work -- it is a standalone
export that only needs the cn utility and the three dependencies above.

## API

Prop | Type | Default | Notes
---- | ---- | ------- | -----
title | string | "Bitcoin BTC" | Centred header line.
duration | string | "2 months challenge" | Sub-line under the title.
amount | number | 55320 | Controlled. Changing it counts the readout up and redraws the curve.
goal | number | 68120 | Target. Drives remaining and, unless progress is set, the curve.
progress | number | amount / goal | 0-1 override for when progress is not a simple ratio.
currency | string | "USD" | ISO 4217 code, formatted via Intl.NumberFormat.
locale | string | "en-US" | BCP 47 tag. Governs grouping, symbol position, compact suffix.
accent | string | "#d8ec4a" | Single accent: curve, milestone nodes, primary button, focus ring.
participants | SavingsChallengeParticipant[] | [] | { name, src?, initials?, amount?, tint? }. src renders a photo, initials is the fallback. First two show, the rest roll into "+n". Empty renders the invite state.
loading | boolean | false | Skeleton: unlit matrix, suppressed labels and accent.
totalLabel | string | "Total Amount" | Caption under the readout.
remainingLabel | string | "Left to reach the goal" | Caption above the remaining figure.
emptyLabel | string | "No one yet" | Shown in the pill when participants is empty.
depositLabel | string | "Add to this challenge" | Accessible label for the primary button.
onDeposit | () => void | -- | Fired by the primary button. The card renders no deposit UI -- open your own sheet/modal in onDeposit, as the demo does.
onToggleRoster | (open: boolean) => void | -- | Fired when the contributor drawer opens or closes.

## Material notes

- Shell: #202020 -> #191919 top-lit gradient, black/50 hairline border,
  plastic-noise.svg at 180px tiled at 20% opacity overlay blend, five
  stacked shadows for lift off the app's #030304 canvas. Same recipe as
  ReceiptPrinter.Machine.
- Cavity (the readout, and the roster drawer): flat #111111, a 0.5px
  white rim-light shadow, and a 24px inset vignette. Radius is the shell
  radius minus its inset via CSS custom properties, so the curves nest.
- Wells: #0a0a0a, same rim-light-plus-inset-shadow pair, for every
  circular control. The primary button is the one solid accent-filled
  object in the piece; it presses 1.5px down on click.
- Motion: uses motion (the ReceiptPrinter dependency) for the count-up,
  the progress arc, and the roster drawer, and respects
  useReducedMotion throughout.

## Handing this to Claude Code

Suggested instruction once these files are copied into the repo:

  "Implement these files into the existing usual-ui repository, following
  its conventions. Verify the component compiles against the repo's
  TypeScript config, that the Tailwind arbitrary-value classes resolve
  under its Tailwind v4 setup, and that public/textures/plastic-noise.svg
  already exists (it does, from ReceiptPrinter) rather than duplicating
  it. Optionally wire up a showcase route and Home entry per the README."
