# VintageKeyboard Component

High-fidelity interactive mechanical keyboard mockup for React. Features multiple layouts (full/compact/60%/ISO), themes (graphite/ivory/olive), and authentic mechanical key press animation with sound and haptics.

## Installation

Copy files into `src/components/VintageKeyboard/`:
- VintageKeyboard.tsx
- types.ts
- index.ts
- styles.css (optional)

Include Google Fonts in your global styles:
```html
<link href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&display=swap" rel="stylesheet">
```

## Quick Usage

```jsx
import VintageKeyboard from "@/components/VintageKeyboard";

export default function Page() {
  return <VintageKeyboard theme="ivory" layout="full" />;
}
```

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `theme` | `"graphite" \| "ivory" \| "olive"` | `"ivory"` | Color theme |
| `layout` | `"full" \| "compact" \| "numpad" \| "iso"` | `"full"` | Physical keyboard layout |
| `size` | `"default" \| "compact"` | `"default"` | Overall size scale |
| `soundEnabled` | `boolean` | `true` | Enable click sound feedback |
| `haptics` | `boolean` | `true` | Enable haptic feedback |
| `activeKeys` | `string[]` | `[]` | Key codes currently pressed (external state) |
| `disabledKeys` | `string[]` | `[]` | Key codes to disable |
| `onKeyPress` | `(e) => void` | — | Callback on key press |
| `accentKeys` | `string[]` | `["Escape", "Enter", "Backspace", "Delete", "Space"]` | Key codes highlighted in red |

## onKeyPress Callback

```typescript
onKeyPress: (e: {
  code: string;        // StandardKey code (e.g., "KeyA")
  char: string | null; // Character output or null for non-char keys
  shift: boolean;      // Shift modifier state
  caps: boolean;       // Caps lock state
}) => void
```

## Features

- **Multiple Themes**: Graphite (dark), Ivory (cream), Olive (green)
- **4 Layouts**: Full (104-key), Compact (60%), Numpad, ISO
- **Mechanical Animation**: Key press depth with spring easing
- **Dual-Frequency Sound**: Bandpass-filtered noise + sine tone per key type
- **Haptic Feedback**: Vibration API support (mobile/supported devices)
- **State Management**: Shift/Caps lock tracking, disabled keys
- **Responsive**: Scales to container width automatically
- **No Dependencies**: React hooks only, no external UI libraries

## Browser Support

- Chrome/Edge 88+
- Firefox 87+
- Safari 14+
- Web Audio API for sound (gracefully degrades)
- Vibration API for haptics (optional)

## Architecture

- **State**: React `scale` only (responsive sizing)
- **UI State**: Ref-based for performance (key press, modifiers)
- **Animation**: CSS transform + transition (hardware-accelerated)
- **Press State**: DOM data-attribute (`data-pressed`) for zero render lag
- **Audio**: Web Audio API with procedurally-generated click sounds
- **Responsive**: ResizeObserver for container fit

## Customization

### Add a New Theme

Edit VintageKeyboard.tsx, `palette()` function:

```typescript
const palette = React.useMemo(() => {
  if (theme === "myTheme") return {
    shellA: "#...",
    shellB: "#...",
    deck: "#...",
    well: "#...",
    capTop: "#...",
    capMid: "#...",
    capBot: "#...",
    edge: "#...",
    legend: "#...",
    modTop: "#...",
    modMid: "#...",
    modBot: "#...",
    modEdge: "#...",
    modLegend: "#...",
  };
  // ...
}, [theme]);
```

### Disable Sound/Haptics Globally

Modify default props in the component signature.

## Dependencies

- React 16.8+ (hooks)
- No npm packages required

## Integration for usual-ui

1. Place in `src/components/VintageKeyboard/`
2. Component uses `"use client"` directive (Next.js App Router)
3. All styles are inline (no Tailwind dependency)
4. Geist font stack matches usual-ui design
5. Texture (plastic-noise) embedded as data URI

## License

Built for usual-ui. Include appropriate attribution per project license.
