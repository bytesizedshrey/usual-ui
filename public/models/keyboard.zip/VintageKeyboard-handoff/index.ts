"use client";

export { default as VintageKeyboard } from "./VintageKeyboard";
export type { VintageKeyboardProps, VintageKeyboardTheme, VintageKeyboardLayout, VintageKeyboardSize } from "./types";
