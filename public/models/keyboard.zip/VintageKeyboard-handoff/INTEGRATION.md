# VintageKeyboard Integration Guide

## Quick Setup

1. Copy all files into `src/components/VintageKeyboard/`
2. Import: `import VintageKeyboard from "@/components/VintageKeyboard"`
3. No additional npm dependencies

## Architecture Notes

### State Management
- **React state**: `scale` (responsive sizing only)
- **Instance state (uiRef)**: key press state, modifier keys, audio context
- **Direct DOM updates**: `data-pressed` attribute for press animation (zero render lag)

### Styling
- Pure inline styles (no CSS classes)
- All color palettes computed in `palette()` memoized function
- Press animation: CSS `transform` + `transition` (hardware-accelerated)
- Texture: embedded as SVG data URI

### Performance
- **ResizeObserver**: responsive fit to container
- **Memoization**: layout rows, palette (avoid wasteful recomputation)
- **Audio Context**: pooled in ref, sample buffers created once, reused
- **Pointer Capture**: smooth multi-key input handling

### Browser APIs Used
- **KeyboardEvent**: keyboard input passthrough
- **PointerEvent**: mouse/touch input with capture
- **AudioContext**: Web Audio API for procedural click sound
- **ResizeObserver**: responsive scaling
- **Vibration API**: haptic feedback (optional, graceful degradation)

## Customization

### Change Default Props
Edit function signature:
```typescript
export default function VintageKeyboard({
  theme = "graphite",  // change here
  layout = "compact",  // or here
  size = "default",
  // ...
})
```

### Add New Theme
See README.md for palette structure. All 14 color slots required.

### Disable Sound/Haptics
Pass `soundEnabled={false}` or `haptics={false}` to instances, or modify defaults.

## Testing

### Unit Test Mocking
```javascript
global.AudioContext = class {
  createBuffer() { return { getChannelData: () => new Float32Array(1000) }; }
  createBufferSource() { return { buffer: null, connect() {}, start() {}, stop() {} }; }
  createBiquadFilter() { return { type: "", frequency: {}, Q: {}, connect() {} }; }
  createOscillator() { return { type: "", frequency: {}, connect() {}, start() {}, stop() {} }; }
  createGain() { return { gain: { setValueAtTime() {}, exponentialRampToValueAtTime() {} }, connect() {} }; }
  get state() { return "running"; }
  resume() { }
  close() { }
};

global.ResizeObserver = class {
  observe() { }
  disconnect() { }
  unobserve() { }
};
```

### Visual Tests
- Test all 3 themes × 4 layouts (12 combinations)
- Verify key press animation (DevTools 6fps + slow-motion)
- Test haptics on mobile
- Verify audio in DevTools Audio context tab

## Known Limitations

1. **Texture**: Currently embedded as data URI. To use public file:
   - Save `plastic-noise.svg` to `public/textures/`
   - Change backgroundImage URL in component

2. **Fonts**: Relies on Google Fonts CDN. For offline use, replace with local font files.

3. **Audio**: May be blocked in some iframe contexts. Gracefully degrades to no sound.

4. **Haptics**: Only devices supporting `navigator.vibrate`. Desktop falls back silently.

## Migration from Design (VintageKeyboard.dc.html)

The `.dc.html` is the design prototype. The `.tsx` is production.

Differences:
- DC uses design-system patterns; TSX uses standard React
- No DC runtime in TSX
- All styles inline (no separate stylesheet)
- Props/types formalized
- Audio/haptics initialization simplified

## Exports

```typescript
export type VintageKeyboardTheme;
export type VintageKeyboardLayout;
export type VintageKeyboardSize;
export interface VintageKeyboardProps;
export default function VintageKeyboard(props: VintageKeyboardProps);
```

## Support

Refer to README.md for usage docs, or VintageKeyboard.tsx for full implementation details.
