export type VintageKeyboardTheme = "graphite" | "ivory" | "olive";
export type VintageKeyboardLayout = "full" | "compact" | "numpad" | "iso";
export type VintageKeyboardSize = "default" | "compact";

export interface VintageKeyboardProps {
  theme?: VintageKeyboardTheme;
  layout?: VintageKeyboardLayout;
  size?: VintageKeyboardSize;
  soundEnabled?: boolean;
  haptics?: boolean;
  activeKeys?: string[];
  disabledKeys?: string[];
  onKeyPress?: (e: { code: string; char: string | null; shift: boolean; caps: boolean }) => void;
  accentKeys?: string[];
}
