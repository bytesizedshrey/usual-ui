import * as THREE from 'three';

// ---- materials -------------------------------------------------------------
export function makeMaterials() {
  const paint = new THREE.MeshPhysicalMaterial({
    name: 'paint', color: 0x3b444c, metalness: 0.6, roughness: 0.24,
    clearcoat: 1, clearcoatRoughness: 0.05, envMapIntensity: 1.5,
  });
  const paintDark = new THREE.MeshPhysicalMaterial({
    name: 'paint_dark', color: 0x1d2227, metalness: 0.6, roughness: 0.34,
    clearcoat: 1, clearcoatRoughness: 0.1, envMapIntensity: 0.9,
  });
  const glass = new THREE.MeshPhysicalMaterial({
    name: 'glass', color: 0x0d1319, metalness: 0.2, roughness: 0.035,
    transparent: true, opacity: 0.78, transmission: 0.18, ior: 1.5,
    clearcoat: 1, clearcoatRoughness: 0.02, envMapIntensity: 2.6,
    side: THREE.DoubleSide,
  });
  const trim = new THREE.MeshStandardMaterial({
    name: 'trim', color: 0x0c0f12, metalness: 0.5, roughness: 0.55, envMapIntensity: 0.7,
  });
  const chrome = new THREE.MeshStandardMaterial({
    name: 'chrome', color: 0x9aa4ac, metalness: 1, roughness: 0.18, envMapIntensity: 1.6,
  });
  const rubber = new THREE.MeshStandardMaterial({
    name: 'rubber', color: 0x0a0b0d, metalness: 0.05, roughness: 0.85, envMapIntensity: 0.35,
  });
  const rim = new THREE.MeshStandardMaterial({
    name: 'rim', color: 0x2e3a36, metalness: 0.95, roughness: 0.3, envMapIntensity: 1.3,
  });
  const lampCool = new THREE.MeshStandardMaterial({
    name: 'lamp_front', color: 0xdfeef4, emissive: 0xbfe6f2, emissiveIntensity: 0.85,
    metalness: 0.2, roughness: 0.25,
  });
  const lampRear = new THREE.MeshStandardMaterial({
    name: 'lamp_rear', color: 0x2a0a0c, emissive: 0xff2a35, emissiveIntensity: 1.1,
    metalness: 0.3, roughness: 0.3,
  });
  const emerald = new THREE.MeshStandardMaterial({
    name: 'charge_emissive', color: 0x0b1a14, emissive: 0x27f59a, emissiveIntensity: 0.7,
    metalness: 0.2, roughness: 0.4,
  });
  return { paint, paintDark, glass, trim, chrome, rubber, rim, lampCool, lampRear, emerald };
}

// ---- geometry helpers ------------------------------------------------------
function extrude(shape, depth, bevel, segs = 6) {
  const g = new THREE.ExtrudeGeometry(shape, {
    depth: depth - bevel * 2, bevelEnabled: true, bevelThickness: bevel,
    bevelSize: bevel, bevelOffset: 0, bevelSegments: segs, curveSegments: 26,
  });
  g.translate(0, 0, -(depth - bevel * 2) / 2);
  g.computeVertexNormals();
  return g;
}

// Plan-view taper: squeeze width toward the nose/tail so the body is not a slab.
function taperZ(geo, opts) {
  const { front = 2.4, rear = -2.4, amt = 0.16, pow = 2.2, rearAmt = amt } = opts;
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), z = p.getZ(i);
    const t = x >= 0 ? Math.min(1, x / front) : Math.min(1, x / rear);
    const a = x >= 0 ? amt : rearAmt;
    p.setZ(i, z * (1 - a * Math.pow(t, pow)));
  }
  p.needsUpdate = true;
  geo.computeVertexNormals();
  return geo;
}

function roundedShape(pts, r) {
  const s = new THREE.Shape();
  const n = pts.length;
  for (let i = 0; i < n; i++) {
    const prev = pts[(i - 1 + n) % n], cur = pts[i], next = pts[(i + 1) % n];
    const v1 = new THREE.Vector2(prev[0] - cur[0], prev[1] - cur[1]);
    const v2 = new THREE.Vector2(next[0] - cur[0], next[1] - cur[1]);
    const r1 = Math.min(r, v1.length() / 2), r2 = Math.min(r, v2.length() / 2);
    const a = new THREE.Vector2(cur[0], cur[1]).add(v1.clone().normalize().multiplyScalar(r1));
    const b = new THREE.Vector2(cur[0], cur[1]).add(v2.clone().normalize().multiplyScalar(r2));
    if (i === 0) s.moveTo(a.x, a.y); else s.lineTo(a.x, a.y);
    s.quadraticCurveTo(cur[0], cur[1], b.x, b.y);
  }
  s.closePath();
  return s;
}

// ---- side profiles ---------------------------------------------------------
// Cross-section camber: tuck the sills in and roll the shoulder over, so the
// flanks read as a curved surface instead of a slab.
function camberY(geo, { low, high, lowScale = 0.88, highScale = 0.93 }) {
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const y = p.getY(i), z = p.getZ(i);
    const t = Math.min(1, Math.max(0, (y - low) / (high - low)));
    const bell = Math.sin(Math.PI * t);
    const edge = t < 0.5 ? lowScale : highScale;
    p.setZ(i, z * (edge + (1 - edge) * Math.pow(bell, 0.6)));
  }
  p.needsUpdate = true;
  geo.computeVertexNormals();
  return geo;
}

function lowerBodyShape() {
  const s = new THREE.Shape();
  s.moveTo(-2.30, 0.80);
  s.quadraticCurveTo(-2.32, 0.58, -2.28, 0.52);        // rear bumper roll
  s.lineTo(-2.19, 0.52);
  s.absarc(-1.66, 0.44, 0.53, Math.PI, 0, true);       // rear wheel arch opening
  s.lineTo(1.09, 0.50);                                // rocker
  s.absarc(1.62, 0.44, 0.53, Math.PI, 0, true);        // front wheel arch opening
  s.lineTo(2.19, 0.52);
  s.quadraticCurveTo(2.38, 0.60, 2.50, 0.86);          // front bumper / fascia
  s.quadraticCurveTo(2.54, 0.98, 2.30, 1.055);         // nose / hood leading edge
  s.bezierCurveTo(2.02, 1.10, 1.80, 1.115, 1.56, 1.11); // hood
  s.bezierCurveTo(0.60, 1.135, -0.55, 1.16, -1.34, 1.195); // beltline
  s.quadraticCurveTo(-2.06, 1.215, -2.26, 1.09);       // rear quarter
  s.quadraticCurveTo(-2.36, 1.00, -2.30, 0.80);
  s.closePath();
  return s;
}

function greenhouseShape() {
  const s = new THREE.Shape();
  s.moveTo(1.52, 1.06);
  s.quadraticCurveTo(1.14, 1.42, 0.78, 1.74);           // windshield / A-pillar
  s.quadraticCurveTo(0.26, 1.845, -0.46, 1.845);        // roof (flatter)
  s.quadraticCurveTo(-1.14, 1.835, -1.62, 1.72);        // rear roof
  s.quadraticCurveTo(-1.92, 1.60, -2.04, 1.20);         // D-pillar / hatch
  s.lineTo(1.52, 1.06);
  s.closePath();
  return s;
}

function windowPane(kind) {
  if (kind === 'front') {
    return roundedShape([[0.22, 1.185], [1.09, 1.185], [0.69, 1.67], [0.29, 1.685]], 0.085);
  }
  if (kind === 'rear') {
    return roundedShape([[-1.22, 1.185], [0.08, 1.185], [0.08, 1.675], [-1.08, 1.665]], 0.085);
  }
  return roundedShape([[-1.72, 1.20], [-1.38, 1.20], [-1.30, 1.655], [-1.56, 1.60]], 0.06);
}

// ---- wheels ----------------------------------------------------------------
function buildWheel(M) {
  const w = new THREE.Group();
  w.name = 'wheel';
  const R = 0.44, halfW = 0.15, rimR = 0.312;

  // tire cross-section, revolved -> rounded shoulders, real sidewall bulge
  const pts = [];
  pts.push(new THREE.Vector2(rimR, -halfW));
  pts.push(new THREE.Vector2(R - 0.055, -halfW - 0.012));
  pts.push(new THREE.Vector2(R - 0.012, -halfW * 0.82));
  pts.push(new THREE.Vector2(R, -halfW * 0.55));
  pts.push(new THREE.Vector2(R, halfW * 0.55));
  pts.push(new THREE.Vector2(R - 0.012, halfW * 0.82));
  pts.push(new THREE.Vector2(R - 0.055, halfW + 0.012));
  pts.push(new THREE.Vector2(rimR, halfW));
  const tire = new THREE.Mesh(new THREE.LatheGeometry(pts, 64), M.rubber);
  tire.name = 'tire';
  tire.rotation.x = Math.PI / 2;
  tire.castShadow = true;
  w.add(tire);

  const face = new THREE.Mesh(new THREE.CylinderGeometry(rimR, rimR * 0.99, 0.11, 56), M.rim);
  face.name = 'rim_face';
  face.rotation.x = Math.PI / 2;
  face.position.z = halfW - 0.055;
  w.add(face);

  const dish = new THREE.Mesh(new THREE.CylinderGeometry(rimR * 0.86, rimR * 0.7, 0.16, 48), M.trim);
  dish.name = 'rim_dish';
  dish.rotation.x = Math.PI / 2;
  dish.position.z = halfW - 0.14;
  w.add(dish);

  const lip = new THREE.Mesh(new THREE.TorusGeometry(rimR - 0.008, 0.016, 12, 64), M.chrome);
  lip.name = 'rim_lip';
  lip.position.z = halfW - 0.012;
  w.add(lip);

  const spokes = new THREE.Group();
  spokes.name = 'spokes';
  for (let i = 0; i < 10; i++) {
    const sp = new THREE.Mesh(new THREE.BoxGeometry(0.245, 0.06, 0.05), M.trim);
    sp.name = `spoke_${i}`;
    const a = (i / 10) * Math.PI * 2;
    sp.position.set(Math.cos(a) * 0.162, Math.sin(a) * 0.162, halfW - 0.006);
    sp.rotation.z = a;
    spokes.add(sp);
  }
  w.add(spokes);

  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.062, 0.058, 0.055, 32), M.chrome);
  hub.name = 'hub';
  hub.rotation.x = Math.PI / 2;
  hub.position.z = halfW + 0.01;
  w.add(hub);
  return w;
}

// ---- car -------------------------------------------------------------------
export function buildCar(M) {
  const car = new THREE.Group();
  car.name = 'ev_vehicle';
  const BW = 1.96, GW = 1.70;

  const body = new THREE.Mesh(
    camberY(
      taperZ(extrude(lowerBodyShape(), BW, 0.22, 8), { amt: 0.20, rearAmt: 0.15, pow: 2.4 }),
      { low: 0.44, high: 1.20, lowScale: 0.84, highScale: 0.91 },
    ),
    M.paint,
  );
  body.name = 'body_lower';
  body.castShadow = true;
  body.receiveShadow = true;
  car.add(body);

  const cabin = new THREE.Mesh(
    camberY(
      taperZ(extrude(greenhouseShape(), GW, 0.15, 8), { front: 1.5, rear: -1.97, amt: 0.14, rearAmt: 0.2, pow: 2 }),
      { low: 1.06, high: 1.85, lowScale: 0.97, highScale: 0.82 },
    ),
    M.paint,
  );
  cabin.name = 'greenhouse';
  cabin.castShadow = true;
  car.add(cabin);

  // beltline trim + door seams (thin plates just off the surface)
  const seams = new THREE.Group();
  seams.name = 'panel_seams';
  [[-1.30, 0.86, 0.86], [0.16, 0.88, 0.90], [1.44, 0.94, 0.80]].forEach(([x, y, h], i) => {
    const g = new THREE.BoxGeometry(0.012, h, 0.02);
    [-1, 1].forEach((s) => {
      const m = new THREE.Mesh(g, M.trim);
      m.name = `seam_${i}_${s > 0 ? 'r' : 'l'}`;
      m.position.set(x, y, s * (BW / 2 - 0.055));
      seams.add(m);
    });
  });
  car.add(seams);

  const belt = new THREE.Mesh(new THREE.BoxGeometry(2.9, 0.026, GW + 0.045), M.chrome);
  belt.name = 'beltline_trim';
  belt.position.set(-0.28, 1.142, 0);
  belt.rotation.z = 0.012;
  car.add(belt);

  // glass
  ['front', 'rear', 'quarter'].forEach((kind) => {
    const g = extrude(windowPane(kind), 0.05, 0.018, 4);
    [-1, 1].forEach((s) => {
      const m = new THREE.Mesh(g, M.glass);
      m.name = `glass_${kind}_${s > 0 ? 'r' : 'l'}`;
      m.position.z = s * (GW / 2 - 0.10);
      car.add(m);
    });
  });

  const wsGeo = new THREE.BoxGeometry(0.82, 0.026, GW - 0.40);
  const ws = new THREE.Mesh(wsGeo, M.glass);
  ws.name = 'windshield';
  ws.position.set(1.10, 1.39, 0);
  ws.rotation.z = -0.70;
  car.add(ws);

  const hatch = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.026, GW - 0.52), M.glass);
  hatch.name = 'hatch_glass';
  hatch.position.set(-1.84, 1.42, 0);
  hatch.rotation.z = 0.86;
  car.add(hatch);

  // wheel wells + wheels
  const AX = [1.62, -1.66];
  AX.forEach((x, i) => {
    const arch = new THREE.Mesh(new THREE.TorusGeometry(0.535, 0.095, 14, 44, Math.PI * 1.06), M.trim);
    arch.name = `arch_${i}`;
    arch.rotation.y = Math.PI / 2;
    arch.rotation.x = -0.03;
    arch.position.set(x, 0.44, 0);
    arch.scale.set(1, 1, 1);
    const archL = arch.clone();
    car.add(arch);
    archL.name = `arch_inner_${i}`;
    archL.scale.setScalar(0.98);
    car.add(archL);

    [-1, 1].forEach((s) => {
      const w = buildWheel(M);
      w.name = `wheel_${i}_${s > 0 ? 'r' : 'l'}`;
      w.position.set(x, 0.44, s * (BW / 2 - 0.025));
      if (s < 0) w.rotation.y = Math.PI;
      car.add(w);
    });
  });

  // lamps
    const hl = extrude(roundedShape([[2.16, 0.99], [2.47, 1.015], [2.46, 0.895], [2.18, 0.865]], 0.045), 0.09, 0.028, 4);
  [-1, 1].forEach((s) => {
    const m = new THREE.Mesh(hl, M.lampCool);
    m.name = `headlamp_${s > 0 ? 'r' : 'l'}`;
    m.position.z = s * (BW / 2 - 0.19);
    car.add(m);
  });
  const tl = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.1, BW - 0.44), M.lampRear);
  tl.name = 'taillamp_bar';
  tl.position.set(-2.315, 1.02, 0);
  car.add(tl);

  // lower fascia / skid + charging receiver pad under the floor
  const skirt = new THREE.Mesh(new THREE.BoxGeometry(2.55, 0.12, BW - 0.30), M.trim);
  skirt.name = 'rocker_skirt';
  skirt.position.set(-0.03, 0.52, 0);
  car.add(skirt);

  const pad = new THREE.Mesh(new THREE.BoxGeometry(1.05, 0.045, 0.86), M.emerald);
  pad.name = 'receiver_pad';
  pad.position.set(-0.05, 0.47, 0);
  car.add(pad);

  return car;
}
