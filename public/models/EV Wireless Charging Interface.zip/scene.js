import * as THREE from 'three';
import { makeMaterials, buildCar } from './car-model.js';

const host = document.getElementById('stage');
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.32;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
host.appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(24, 1, 0.1, 100);
camera.position.set(1.5, 1.85, 12.8);
camera.lookAt(0, 0.98, 0);

// ---- procedural studio environment (equirect gradient -> PMREM) ------------
function envTexture() {
  const w = 512, h = 256;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, '#20303c');
  g.addColorStop(0.34, '#4c6472');
  g.addColorStop(0.5, '#0e1519');
  g.addColorStop(1, '#04070a');
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  // soft overhead strip lights — these are what draw the long body highlights
  ctx.globalCompositeOperation = 'lighter';
  [[0.16, 0.10, 190, 34], [0.62, 0.12, 150, 26], [0.88, 0.20, 90, 18]].forEach(([x, y, bw, bh]) => {
    const rg = ctx.createRadialGradient(x * w, y * h, 0, x * w, y * h, bw);
    rg.addColorStop(0, 'rgba(255,255,255,0.95)');
    rg.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = rg;
    ctx.save(); ctx.translate(x * w, y * h); ctx.scale(1, bh / bw); ctx.translate(-x * w, -y * h);
    ctx.fillRect(0, 0, w, h); ctx.restore();
  });
  // charging floor bounce
  const fg = ctx.createRadialGradient(w * 0.5, h * 0.94, 0, w * 0.5, h * 0.94, 200);
  fg.addColorStop(0, 'rgba(39,245,154,0.5)');
  fg.addColorStop(1, 'rgba(39,245,154,0)');
  ctx.fillStyle = fg; ctx.fillRect(0, h * 0.6, w, h * 0.4);
  const t = new THREE.CanvasTexture(c);
  t.mapping = THREE.EquirectangularReflectionMapping;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
const pmrem = new THREE.PMREMGenerator(renderer);
pmrem.compileEquirectangularShader();
const envRT = pmrem.fromEquirectangular(envTexture());
scene.environment = envRT.texture;

// ---- lights ----------------------------------------------------------------
scene.add(new THREE.HemisphereLight(0x7d9cae, 0x05221a, 0.85));

const key = new THREE.DirectionalLight(0xdff0ff, 2.7);
key.position.set(5.5, 8.5, 5.2);
key.castShadow = true;
key.shadow.mapSize.set(2048, 2048);
key.shadow.camera.left = -6; key.shadow.camera.right = 6;
key.shadow.camera.top = 6; key.shadow.camera.bottom = -6;
key.shadow.radius = 5;
key.shadow.bias = -0.0009;
scene.add(key);

const fill = new THREE.DirectionalLight(0x8fd6ff, 0.5);
fill.position.set(-7, 3.5, 4);
scene.add(fill);

const rim = new THREE.SpotLight(0xa9f5ff, 8, 14, 0.9, 0.8, 1.4);
rim.position.set(-4.5, 3.2, -5);
scene.add(rim);

// charging field uplight: green spill onto the underbody, sills and wheels
const charge = new THREE.PointLight(0x2bf59c, 12, 6.5, 2.1);
charge.position.set(0, 0.12, 0);
scene.add(charge);
const chargeWide = new THREE.PointLight(0x1fd7c8, 5, 9, 2.3);
chargeWide.position.set(-0.4, 0.05, 1.2);
scene.add(chargeWide);

// ---- floor: dark automotive surface + wireless field ----------------------
function floorTexture() {
  const s = 1024;
  const c = document.createElement('canvas');
  c.width = s; c.height = s;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#05080b'; ctx.fillRect(0, 0, s, s);
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s * 0.46);
  g.addColorStop(0, 'rgba(46,255,168,0.75)');
  g.addColorStop(0.25, 'rgba(30,214,166,0.30)');
  g.addColorStop(0.55, 'rgba(20,120,120,0.09)');
  g.addColorStop(1, 'rgba(5,8,11,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, s, s);
  ctx.strokeStyle = 'rgba(150,220,225,0.16)';
  [0.30, 0.38, 0.455].forEach((r, i) => {
    ctx.lineWidth = i === 2 ? 2.5 : 1.5;
    ctx.beginPath(); ctx.arc(s / 2, s / 2, s * r, 0, Math.PI * 2); ctx.stroke();
  });
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
const floorTex = floorTexture();
const floor = new THREE.Mesh(
  new THREE.CircleGeometry(6.6, 96),
  new THREE.MeshStandardMaterial({
    name: 'floor', color: 0x0a0e12, roughness: 0.62, metalness: 0.12,
    map: floorTex, emissive: 0xffffff, emissiveMap: floorTex, emissiveIntensity: 0.5,
    envMapIntensity: 0.5, transparent: true,
  }),
);
floor.name = 'floor';
floor.rotation.x = -Math.PI / 2;
floor.receiveShadow = true;
scene.add(floor);

// contact shadow: soft baked blob right under the body, below the raytraced one
function blobTexture() {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = s; c.height = s;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  g.addColorStop(0, 'rgba(0,0,0,0.92)');
  g.addColorStop(0.45, 'rgba(0,0,0,0.55)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, s, s);
  return new THREE.CanvasTexture(c);
}
const blob = new THREE.Mesh(
  new THREE.PlaneGeometry(5.3, 2.1),
  new THREE.MeshBasicMaterial({ map: blobTexture(), transparent: true, opacity: 0.85, depthWrite: false }),
);
blob.name = 'contact_shadow';
blob.rotation.x = -Math.PI / 2;
blob.position.y = 0.012;
scene.add(blob);

// wireless power rings
const rings = [];
for (let i = 0; i < 4; i++) {
  const m = new THREE.Mesh(
    new THREE.TorusGeometry(1.55 + i * 0.5, 0.011, 8, 140),
    new THREE.MeshBasicMaterial({ color: 0x4dffb8, transparent: true, opacity: 0.34, depthWrite: false }),
  );
  m.name = `field_ring_${i}`;
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.02;
  m.scale.z = 0.42;
  rings.push(m);
  scene.add(m);
}

const materials = makeMaterials();
const car = buildCar(materials);
car.rotation.y = -0.17;
scene.add(car);

function resize() {
  const w = host.clientWidth, h = host.clientHeight;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(host);
resize();

let t0 = performance.now();
let energy = 1;
function frame(now) {
  const t = (now - t0) / 1000;
  energy += ((window.__charging === false ? 0 : 1) - energy) * 0.06;
  rings.forEach((r, i) => {
    const p = (t * 0.34 + i * 0.25) % 1;
    r.scale.setScalar(0.55 + p * 1.1);
    r.scale.z = (0.55 + p * 1.1) * 0.4;
    r.material.opacity = 0.3 * (1 - p) * (1 - p) * energy;
    r.position.y = 0.02 + p * 0.12;
  });
  charge.intensity = (11 + Math.sin(t * 1.7) * 2.4) * (0.12 + energy * 0.88);
  chargeWide.intensity = 5 * (0.15 + energy * 0.85);
  materials.emerald.emissiveIntensity = 0.7 * energy;
  floor.material.emissiveIntensity = (0.46 + Math.sin(t * 1.7) * 0.07) * (0.2 + energy * 0.8);
  car.position.y = Math.sin(t * 0.5) * 0.004;
  camera.position.x = 1.5 + Math.sin(t * 0.18) * 0.16;
  camera.position.y = 1.85 + Math.sin(t * 0.23) * 0.05;
  camera.lookAt(0, 0.98, 0);
  renderer.render(scene, camera);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
window.__evScene = { scene, camera, renderer, car };
