repo: bytesizedshrey/usual-ui
branch: master
path: src

## Last sync
date: 2026-09-11T05:40:00Z

### Updated in this project
- Read the repo's skeuomorphic vocabulary (MusicPlayer3D: studio env, contact shadows, local-space press depth) and its type/color tokens.
- Built a new EV wireless-charging screen using that vocabulary: three.js vehicle, raised/recessed controls.

## Screen map
| Screen | Built from |
| --- | --- |
| ev-wireless-charging.html | src/index.css (type + canvas color), src/components/MusicPlayer3D/MusicPlayer3D.tsx (lighting, contact shadow, press behavior), uploads/carChargingUI.jpg (composition reference) |
