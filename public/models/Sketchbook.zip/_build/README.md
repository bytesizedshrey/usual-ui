# Sketchbook UI Component

A compact, interactive 3D paper sketchbook component built with CSS 3D transforms and vanilla JavaScript. Features nested-strip page curls, direct drag interaction, tilt, zoom, and a movable magnifying glass.

## Overview

- **Presentation**: Compact 640x340px responsive component (scales down to ~500px)
- **Content**: Nine-plate Sadie Sink editorial sketchbook with drawn paper spreads
- **Interactions**: Drag to turn pages, tilt with mouse movement, zoom with controls, draggable magnifying glass
- **Framework**: Design Component (DC) format, embeddable in usual-ui or standalone
- **Dependencies**: None (vanilla JS + CSS 3D)

## Files

- Sketchbook.dc.html - The complete component (template + logic class)
- support.js - DC runtime support (required for component loading)
- _ds/classical-6f577035-ef99-4be8-b7be-9dc401b557ec/ - Classical design system (styles + bundle)

## Usage

### As a Design Component in usual-ui

<dc-import name="Sketchbook" hint-size="640px,340px"></dc-import>

### Standalone

Place Sketchbook.dc.html in a directory with support.js and the _ds folder, then open it directly in a browser.

## Tweaks (Props)

- startPlate (int, 0-8): Which plate to show on load (default: 0)
- magnifier (boolean): Show/hide the magnifying glass (default: true)
- intro (boolean): Play the riffle intro animation (default: true)

## Technical Details

- Spread Geometry: 1760x790px SVG canvases, drawn procedurally with text and vector elements
- 3D: CSS 3D transforms on 18-strip nested structure for smooth page curls
- Paper Simulation: Realistic shadows, light glints, gutter shading on page turn
- Responsive: Scales from 320px (minimal) to ~900px (max-width constraint removed for cards)
- Transparent Root: No background—integrates cleanly into any container

## Integration Notes

1. Ensure support.js is available in the same directory or project root
2. The _ds folder must be preserved at the relative path _ds/classical-6f577035-ef99-4be8-b7be-9dc401b557ec/
3. The component mounts a sandboxed iframe (srcdoc) with full interaction—no CORS issues
4. The loupe (magnifying glass) is touch-aware—hidden on mobile/coarse pointers by default
5. Interactions are keyboard-accessible: arrow keys turn pages, double-click resets zoom

## Customization

To change the authored content (swap from Sadie Sink plates to your own):

1. Edit the spreads() method in the logic class
2. Replace the SVG generation or point to image URLs
3. Update the plates array with your own titles and content
4. Adjust canvas dimensions (W, H, X0, X1, Y0, Y1) if needed

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14.1+
(Requires CSS 3D Transforms and CSS Mask Image)

## Credits

Built on the ThreeUI Sketchbook architecture (https://github.com/zzzzshawn/skeumorphic-ui).
Classical design system styling applied throughout.
